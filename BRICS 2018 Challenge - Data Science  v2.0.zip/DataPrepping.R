
library(dplyr)
#Data Prepping
#WallmartFeatures
WallmartFeatures <- as.data.frame(WalmartFeatures)

head(WallmartFeatures)

#Delete unwanted columns
WallmartFeatures$Store <- NULL
WallmartFeatures$MarkDown1 <- NULL
WallmartFeatures$MarkDown2 <- NULL
WallmartFeatures$MarkDown3 <- NULL
WallmartFeatures$MarkDown4 <- NULL
WallmartFeatures$MarkDown5 <- NULL

#Data Distributions
#Date
head(WallmartFeatures)
hist(as.numeric(WallmartFeatures$Date))
max(as.numeric(WallmartFeatures$Date))

date <- as.Date(WallmartFeatures$Date)
sort(date)
head(sort(date)) #20100205
tail(sort(date)) #20130726

#Other features
hist(WallmartFeatures$Temperature) #normally dist
hist(WallmartFeatures$Fuel_Price)
hist(WallmartFeatures$CPI)
hist(WallmartFeatures$Unemployment)
hist(as.numeric(WallmartFeatures$IsHoliday)) #class imbalance

#Creating weekly buckets
WM_weekly <- as.Date(WallmartFeatures$Date)
summary(WM_weekly)
